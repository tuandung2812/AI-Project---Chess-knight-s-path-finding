import random
from .knight_board import Board


class Problem:
    """
    board_size (int): size of the board
    num_coin (int): number of coins on board
    num_obstacles (int): number of obstacles on board
    knight_pos (tuple): optional, initial position of the knight
    dest_pos (tuple): optional, the position of the goal
    """

    def __init__(self, board_size, num_coin, num_obstacles, coin_pos_set=None, obstacle_pos_set=None, knight_pos=None,
                 dest_pos=None,algorithm=None):
        self.board_size = board_size
        self.num_coin = num_coin
        self.num_obstacles = num_obstacles
        self.coin_pos_set = coin_pos_set
        self.obstacle_pos_set = obstacle_pos_set
        self.knight_pos = knight_pos
        self.dest_pos = dest_pos
        self.algorithm=algorithm

        if self.knight_pos == None:
            self.knight_pos = self.generate_knight_pos()
        if self.dest_pos == None:
            self.dest_pos = self.generate_dest_pos()
        if self.coin_pos_set == None:
            self.coin_pos_set = self.generate_coin()
        if self.obstacle_pos_set == None:
            self.obstacle_pos_set = self.generate_obstacle()

    def initial_state(self):
        """
        Return the initial state of the board
        """

        self.board = Board(self.board_size, self.knight_pos, self.dest_pos, self.coin_pos_set,
                           self.obstacle_pos_set,self.algorithm)

        return self.board

    def goal_test(self, state):
        """
        Check if the state is the goal
        """
        if state.knight_pos == state.destination:
            return True
        return False

    def actions(self, state):
        """
        return possible next actions from current state
        """
        possible_moves = state.possible_moves()
        return possible_moves

    def generate_knight_pos(self):
        """
        board_size (int): size of the board

        Return: (tuple) position of the knight
        """
        x = random.randint(0, self.board_size - 1)
        y = random.randint(0, self.board_size - 1)
        return (x, y)

    def generate_dest_pos(self):
        """
        board_size (int): size of the board
        knight_pos (tuple): position of the knight

        Return: position of the goal
        """
        x, y = self.knight_pos
        while (x, y) == self.knight_pos:
            x = random.randint(0, self.board_size - 1)
            y = random.randint(0, self.board_size - 1)
        return (x, y)

    def generate_coin(self):
        """
        num_coin (int): number of coin on the board
        board_size (int): size of the board
        knight_pos (tuple): position of the knight
        dest_pos (tuple): position of the goal

        return: coin_pos_set, a set of all positions of the coins 
        """
        coin_pos_set = set()
        while len(coin_pos_set) < self.num_coin:
            x = random.randint(0, self.board_size - 1)
            y = random.randint(0, self.board_size - 1)
            if (x, y) != self.knight_pos and (x, y) != self.dest_pos:
                coin_pos_set.add((x, y))

        return coin_pos_set

    def generate_obstacle(self):
        """
        num_obstacles (int): number of obstacles on the board
        board_size (int): size of the board
        knight_pos (tuple): position of the knight
        dest_pos (tuple): position of the goal
        coin_pos_set (set of tuples): set of position of coins

        return: obstacle_pos_set, set of all positions of obstacles
        """
        obstacle_pos_set = set()
        while len(obstacle_pos_set) < self.num_obstacles:
            x = random.randint(0, self.board_size - 1)
            y = random.randint(0, self.board_size - 1)
            if (x, y) not in self.coin_pos_set and (x, y) != self.knight_pos and (x, y) != self.dest_pos:
                obstacle_pos_set.add((x, y))
        return obstacle_pos_set
