import math
import random


class Board:
    """
    board_size (int): size of the board
    knight_pos (tuple of int): position of the knight
    destination (tuple of int): position of the goal
    coin_pos_set (set of tuple): set of position of the coins
    obstacle_pos_set (set of tuple): set of position of the obstacles
    """

    def __init__(self, board_size, knight_pos, destination, coin_pos_set, obstacle_pos_set, algorithm):
        self.board_size = board_size
        self.knight_pos = knight_pos
        self.destination = destination
        self.coin_pos_set = coin_pos_set
        self.obstacle_pos_set = obstacle_pos_set
        self.coin_value = -3
        self.normal_value = 1
        if algorithm==None:
          algorithm= input("Please choose algorithm: 'UCS' or 'Astar' or 'backtrack'")
        self.algorithm = algorithm
        if self.algorithm== 'UCS':
          self.goal_value = 3 # math.ceil(board_size*2/3)
        elif self.algorithm== 'Astar':
          self.goal_value = 3
        elif self.algorithm== 'backtrack':
          self.goal_value= 0

    def possible_moves(self):
        """
        return the list of possible next positions of the knight
        """
        x, y = self.knight_pos
        possible_moves = []

        if x - 2 >= 0 and y - 1 >= 0:
            possible_moves.append((x - 2, y - 1))

        if x - 2 >= 0 and y + 1 < self.board_size:
            possible_moves.append((x - 2, y + 1))

        if x - 1 >= 0 and y - 2 >= 0:
            possible_moves.append((x - 1, y - 2))

        if x - 1 >= 0 and y + 2 < self.board_size:
            possible_moves.append((x - 1, y + 2))

        if x + 1 < self.board_size and y - 2 >= 0:
            possible_moves.append((x + 1, y - 2))

        if x + 1 < self.board_size and y + 2 < self.board_size:
            possible_moves.append((x + 1, y + 2))

        if x + 2 < self.board_size and y - 1 >= 0:
            possible_moves.append((x + 2, y - 1))

        if x + 2 < self.board_size and y + 1 < self.board_size:
            possible_moves.append((x + 2, y + 1))

        for i in range(len(possible_moves) - 1, -1, -1):
            if possible_moves[i] in self.obstacle_pos_set:
                possible_moves.pop(i)
        return possible_moves

    def move_knight(self, new_pos):
        """
        Update self.knight_pos to new_pos
        Remove coin from set if knight jump to the square that has coin

        Return the new board and the value of the square that the knight jump to
        """
        assert new_pos in self.possible_moves(), f"The knight can't go to {new_pos}"

        new_coin_set = self.coin_pos_set.copy()
        if new_pos in self.coin_pos_set:
            new_coin_set.remove(new_pos)
            value = self.coin_value
        elif new_pos == self.destination:
            value = self.goal_value
        else:
            value = self.normal_value

        board = Board(self.board_size, new_pos, self.destination, new_coin_set,
                      self.obstacle_pos_set,self.algorithm)

        return board, value