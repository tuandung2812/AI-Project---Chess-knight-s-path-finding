from tkinter import *


def show_board(board_size, knight_pos, coin_set, obs_set, destination, path=[], coin_value=0, normal_value=0):
    print('Rule: Coin +{}, Empty squares {}'.format(-coin_value, -normal_value))
    coin_value = -coin_value
    # window
    window = Tk()
    window.title('Simulation')
    Grid.rowconfigure(window, 0, weight=1)
    Grid.columnconfigure(window, 0, weight=1)
    size = str(int((board_size + 0.5) * 80)) + 'x' + str(int((board_size + 1.5) * 80))
    window.geometry(size)
    square = {}
    window = Frame(master=window)
    w_knight_image = PhotoImage(file="Visual_Demonstrate/images/white_knight.png")
    b_knight_image = PhotoImage(file="Visual_Demonstrate/images/black_knight.png")
    w_mount_img = PhotoImage(file='Visual_Demonstrate/images/white_mountain.png')
    b_mount_img = PhotoImage(file='Visual_Demonstrate/images/black_mountain.png')
    w_coin_img = PhotoImage(file='Visual_Demonstrate/images/white_coin.png')
    b_coin_img = PhotoImage(file='Visual_Demonstrate/images/black_coin.png')
    w_flag_img = PhotoImage(file='Visual_Demonstrate/images/white_flag.png')
    b_flag_img = PhotoImage(file='Visual_Demonstrate/images/black_flag.png')
    Grid.rowconfigure(window, 0, weight=1)
    Grid.columnconfigure(window, 0, weight=1)

    board_frame = Frame(master=window, relief='raised', border=10)

    board_frame.grid(row=0, column=0, sticky=N + S + E + W)
    for i in range(0, board_size + 1):
        if i == 0:
            Grid.columnconfigure(board_frame, i, weight=1, uniform='column')
            Grid.rowconfigure(board_frame, i, weight=1, uniform='row')
        elif i == board_size:
            Grid.columnconfigure(board_frame, i, weight=2, uniform='column')
            Grid.rowconfigure(board_frame, i, weight=2, uniform='row')
        else:
            Grid.columnconfigure(board_frame, i, weight=2, uniform='column')
            Grid.rowconfigure(board_frame, i, weight=2, uniform='row')

        for j in range(0, board_size + 1):
            if i * j == 0:
                if i != 0:
                    row_label = Label(board_frame, text=str(i - 1), font=('arial', 18, 'bold'))
                    row_label.grid(row=i, column=j)
                elif j != 0:
                    col_label = Label(board_frame, text=str(j - 1), font=('arial', 18, 'bold'))
                    col_label.grid(row=i, column=j)
            else:
                if (i % 2) - (j % 2) == 0:
                    square[i, j] = [Frame(board_frame, relief='ridge', border=2, bg='white')]
                    if (i - 1, j - 1) == knight_pos:
                        square[i, j].append(Label(square[i, j][0], image=w_knight_image, bg='white'))
                        Grid.rowconfigure(square[i, j][0], 0, weight=1)
                        Grid.columnconfigure(square[i, j][0], 0, weight=1)
                        square[i, j][1].grid(row=0, column=0, sticky=N + S + E + W)
                    elif (i - 1, j - 1) in obs_set:
                        square[i, j].append(Label(square[i, j][0], image=w_mount_img, bg='white'))
                        Grid.rowconfigure(square[i, j][0], 0, weight=1)
                        Grid.columnconfigure(square[i, j][0], 0, weight=1)
                        square[i, j][1].grid(row=0, column=0, sticky=N + S + E + W)
                    elif (i - 1, j - 1) in coin_set:
                        square[i, j].append(Label(square[i, j][0], image=w_coin_img, bg='white'))
                        Grid.rowconfigure(square[i, j][0], 0, weight=1)
                        Grid.columnconfigure(square[i, j][0], 0, weight=1)
                        square[i, j][1].grid(row=0, column=0, sticky=N + S + E + W)
                    elif (i - 1, j - 1) == destination:
                        square[i, j].append(Label(square[i, j][0], image=w_flag_img, bg='white'))
                        Grid.rowconfigure(square[i, j][0], 0, weight=1)
                        Grid.columnconfigure(square[i, j][0], 0, weight=1)
                        square[i, j][1].grid(row=0, column=0, sticky=N + S + E + W)
                    square[i, j][0].grid(row=i, column=j, sticky=N + S + E + W)

                else:
                    square[i, j] = [Frame(board_frame, bg='black')]
                    if (i - 1, j - 1) == knight_pos:
                        square[i, j].append(Label(square[i, j][0], image=b_knight_image, bg='black'))
                        Grid.rowconfigure(square[i, j][0], 0, weight=1)
                        Grid.columnconfigure(square[i, j][0], 0, weight=1)
                        square[i, j][1].grid(row=0, column=0, sticky=N + S + E + W)
                    elif (i - 1, j - 1) in obs_set:
                        square[i, j].append(Label(square[i, j][0], image=b_mount_img, bg='black'))
                        Grid.rowconfigure(square[i, j][0], 0, weight=1)
                        Grid.columnconfigure(square[i, j][0], 0, weight=1)
                        square[i, j][1].grid(row=0, column=0, sticky=N + S + E + W)
                    elif (i - 1, j - 1) in coin_set:
                        square[i, j].append(Label(square[i, j][0], image=b_coin_img, bg='black'))
                        Grid.rowconfigure(square[i, j][0], 0, weight=1)
                        Grid.columnconfigure(square[i, j][0], 0, weight=1)
                        square[i, j][1].grid(row=0, column=0, sticky=N + S + E + W)
                    elif (i - 1, j - 1) == destination:
                        square[i, j].append(Label(square[i, j][0], image=b_flag_img, bg='black'))
                        Grid.rowconfigure(square[i, j][0], 0, weight=1)
                        Grid.columnconfigure(square[i, j][0], 0, weight=1)
                        square[i, j][1].grid(row=0, column=0, sticky=N + S + E + W)
                    square[i, j][0].grid(row=i, column=j, sticky=N + S + E + W)
    point = 0
    l = 0

    def next_move():
        nonlocal l, point
        if l >= 0 and l < (len(path) - 1):
            (prev_i, prev_j) = path[l][0] + 1, path[l][1] + 1
            (i, j) = path[l + 1][0] + 1, path[l + 1][1] + 1
            square[prev_i, prev_j][1].grid_forget()
            square[prev_i, prev_j].pop()
            if len(square[i, j]) > 1:
                square[i, j][1].grid_forget()
                square[i, j].pop()
                if (i - 1, j - 1) in coin_set:
                    point += coin_value
            else:
                point -= 1
            point_text = 'Point = ' + str(point)
            obj_label.config(text=point_text)
            if (i % 2) - (j % 2) == 0:
                square[i, j].append(Label(square[i, j][0], image=w_knight_image, bg='white'))
            else:
                square[i, j].append(Label(square[i, j][0], image=b_knight_image, bg='black'))

            square[i, j][1].grid(row=0, column=0, sticky=N + S + E + W)
            l += 1
        else:
            pass

    def prev_move():
        nonlocal l, point
        if l > 0 and l < len(path):
            (i, j) = path[l][0] + 1, path[l][1] + 1
            (prev_i, prev_j) = path[l - 1][0] + 1, path[l - 1][1] + 1
            square[i, j][1].grid_forget()
            square[i, j].pop()
            if (i - 1, j - 1) in coin_set and (i - 1, j - 1) not in path[:l]:
                if (i % 2) - (j % 2) == 0:

                    square[i, j].append(Label(square[i, j][0], image=w_coin_img, bg='white'))
                    square[i, j][1].grid(row=0, column=0, sticky=N + S + E + W)
                else:
                    square[i, j].append(Label(square[i, j][0], image=b_coin_img, bg='black'))
                    square[i, j][1].grid(row=0, column=0, sticky=N + S + E + W)
                point -= coin_value
            elif (i - 1, j - 1) == destination:
                if (i % 2) - (j % 2) == 0:
                    square[i, j].append(Label(square[i, j][0], image=w_flag_img, bg='white'))
                    square[i, j][1].grid(row=0, column=0, sticky=N + S + E + W)
                else:
                    square[i, j].append(Label(square[i, j][0], image=b_flag_img, bg='black'))
                    square[i, j][1].grid(row=0, column=0, sticky=N + S + E + W)
            else:
                point += 1
            point_text = 'Point = ' + str(point)
            obj_label.config(text=point_text)
            if (prev_i % 2) - (prev_j % 2) == 0:
                square[prev_i, prev_j].append(Label(square[prev_i, prev_j][0], image=w_knight_image, bg='white'))
            else:
                square[prev_i, prev_j].append(Label(square[prev_i, prev_j][0], image=b_knight_image, bg='black'))

            square[prev_i, prev_j][1].grid(row=0, column=0, sticky=N + S + E + W)
            l -= 1
        else:
            pass

    obj_frame = Frame(master=window, relief='flat', border=5)
    point_text = 'Point = ' + str(0)
    obj_label = Label(master=obj_frame, text=point_text, font=('arial', 18, 'bold'))
    next_move_button = Button(obj_frame, text='Next move', font=('arial', 12, 'bold'), relief='raised', border=4,
                              command=next_move)
    next_move_button.pack(side=RIGHT)
    prev_move_button = Button(obj_frame, text='Prev move', font=('arial', 12, 'bold'), relief='raised', border=4,
                              command=prev_move)
    prev_move_button.pack(side=RIGHT)
    obj_label.pack()
    obj_frame.grid(row=board_size, columnspan=board_size, sticky=N + S + E + W)
    window.grid(row=0, column=0)
    window.lift()
    window.mainloop()
