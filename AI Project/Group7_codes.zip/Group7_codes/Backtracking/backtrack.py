from collections import deque


class Node:
    def __init__(self, board):
        self.state = board

    def __eq__(self, other):
        if self.state.knight_pos == other.state.knight_pos and self.state.coin_pos_set == other.state.coin_pos_set:
            return True
        return False

    def __repr__(self):
        return str(self.state.knight_pos)


def check_feasibility(problem):
    """
    A function to check if the problem is solvable using BFS
    """
    
    initial_node = Node(problem.initial_state())
    if problem.goal_test(initial_node.state):
        return True

    frontier = deque([])
    frontier.appendleft(initial_node)
    explored = set()

    while len(frontier) != 0:
        current_node = frontier.pop()
        explored.add(current_node.state.knight_pos)

        for new_pos in current_node.state.possible_moves():
            next_state, _ = current_node.state.move_knight(new_pos)
            # create child node
            child_node = Node(next_state)
            if child_node.state.knight_pos not in explored:
                if problem.goal_test(child_node.state):
                    return True
                frontier.appendleft(child_node)

    print("Not solvable.")
    return False


def backtracking(problem):
    initial_node = Node(problem.initial_state())
    initial_node.state.goal_value = 0
    path = []
    path.append(initial_node)
    cost = 0
    min_cost = float('inf')
    best_path = []

    def solution():
        nonlocal cost
        nonlocal min_cost
        nonlocal best_path
        if cost < min_cost:
            min_cost = cost
            best_path = path[:]

    def check(node):
        return node not in path

    def Try():
        nonlocal cost
        current_node = path[-1]
        candidates = []

        for new_pos in current_node.state.possible_moves():
            next_state, point_gained = current_node.state.move_knight(new_pos)
            next_state.goal_value = 0
            # create child node
            child_node = Node(next_state)
            candidates.append((child_node, point_gained))

        candidates.sort(key=lambda x: x[1])

        for candidate in candidates:
            child_node = candidate[0]
            point_gained = candidate[1]
            if check(child_node):
                path.append(child_node)
                cost += point_gained

                if problem.goal_test(child_node.state):
                    solution()
                else:
                    estimated_min_cost = cost + child_node.state.coin_value * len(child_node.state.coin_pos_set)
                    if estimated_min_cost < min_cost:
                        Try()

                path.pop()
                cost -= point_gained
    
    Try()
    max_cost = -min_cost

    print(len(best_path))
    print("Best_path:", best_path)
    print("Max cost:", max_cost)

    return best_path, max_cost