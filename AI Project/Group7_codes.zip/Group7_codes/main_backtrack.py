from Backtracking.backtrack import backtracking, check_feasibility
from Environment_and_Problem.problem import Problem
from time import perf_counter
import random


board_size = 5
num_coin = 5
num_obs = 10
random.seed(3)
problem = Problem(board_size=board_size, num_coin=num_coin, num_obstacles=num_obs,algorithm='backtrack')
if check_feasibility(problem):
  start_time = perf_counter()
  best_path, max_cost = backtracking(problem)
  end_time = perf_counter()
  print(end_time - start_time)

input('Enter a key to exit')
