from queue import PriorityQueue


class Node:
    def __init__(self, board):
        self.state = board
        self.parent = None


def child_node(node, action):
    child, gain = node.state.move_knight(action)
    child = Node(child)
    child.parent = node
    return child, gain


def solution(node, point):
    print('Solution found!')
    print('Objective:', -point + node.state.goal_value)
    print('Path:')
    path = []
    path.append(node.state.knight_pos)
    while node.parent != None:
        node = node.parent
        path.append(node.state.knight_pos)
    print(path[::-1])
    path = path[::-1]
    return path, -point + node.state.goal_value


def hash(state):
    hashkey = ''
    hashkey += (str(state.knight_pos[0]) + str(state.knight_pos[1]))
    for item in state.coin_pos_set:
        hashkey += (str(item[0]) + str(item[1]))
    return hashkey


def uniform_cost_search(problem):
    print('\nFinding solution...')
    node = Node(problem.initial_state())
    point = 0
    if problem.goal_test(node.state):
        return solution(node, point)
    queue = PriorityQueue()
    queue.put((point, id(node), node))
    frontier = {}
    frontier[hash(node.state)] = 0
    explored = {}
    parent = {}
    parent[hash(node.state)] = None

    while not queue.empty():
        dequeued_obj = queue.get()
        node = dequeued_obj[2]
        node_key = hash(node.state)
        try:
            del frontier[node_key]
            point = dequeued_obj[0]
            if problem.goal_test(node.state):
                return solution(node, point)
            explored[node_key] = point
            for action in problem.actions(node.state):
                child, gain = child_node(node, action)
                new_point = point
                new_point += gain
                state = hash(child.state)

                if state not in explored and state not in frontier:
                    queue.put((new_point, id(child), child))
                    frontier[state] = new_point
                elif state in explored and new_point < explored[state]:
                    explored[state] = point
                    queue.put((new_point, id(child), child))
                    frontier[state] = new_point
                elif state in frontier and new_point < frontier[state]:
                    queue.put((new_point, id(child), child))
                    frontier[state] = new_point
        except KeyError:
            pass
    print('INFEASIBLE')
    return [],0
