import math


def manhattan(pos1, pos2):
    return abs(pos1[0] - pos2[0]) + abs(pos1[1] - pos2[1])


def heuristic(state):
    coin_pos_set = state.coin_pos_set.copy()
    current_knight_pos = state.knight_pos
    point = 0
    while len(coin_pos_set) > 0:
        min_distance = state.board_size * 2 + 1
        nearest_coin = (0, 0)
        for coin_pos in coin_pos_set:
            distance = manhattan(coin_pos, current_knight_pos)
            if distance < min_distance:
                min_distance = distance
                nearest_coin = coin_pos

        coin_pos_set.remove(nearest_coin)
        current_knight_pos = nearest_coin
        point += (math.ceil((min_distance) / 3) + state.coin_value)

    point += math.ceil(manhattan(state.destination, current_knight_pos) / 3)
    return point
