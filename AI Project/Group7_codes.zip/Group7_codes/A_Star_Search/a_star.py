import heapq
from A_Star_Search.heuristics import heuristic


class Node:
    def __init__(self, board):
        self.state = board
        self.parent = None
        self.game_cost = 0
        self.g = 0
        self.h = 0
        self.f = 0

    def __lt__(self, other):
        return self.f < other.f

    def __str__(self):
        return str(self.state)


def child_node(node, action):
    child, gain = node.state.move_knight(action)
    child = Node(child)
    child.parent = node
    return child, gain


def solution(node):
    path = []
    path.append(node.state.knight_pos)
    while node.parent != None:
        node = node.parent
        path.append(node.state.knight_pos)
    path = path[::-1]
    return path


def a_star(problem):
    initial_node = Node(problem.initial_state())
    num_nodes = 1
    fringe = []
    heapq.heappush(fringe, initial_node)
    knight_node = Node(problem.initial_state())

    while len(fringe) != 0:
        current_node = heapq.heappop(fringe)
        num_nodes += 1
        if num_nodes == 400000:
            print('Exited! No solutions found')
        if problem.goal_test(current_node.state):
            path = solution(current_node)
            final_cost = - (current_node.game_cost - current_node.state.goal_value)
            # print("Number of nodes:", num_nodes)
            return path, final_cost, num_nodes
        for new_pos in current_node.state.possible_moves():
            child, point_gained = child_node(current_node, new_pos)[0], child_node(current_node, new_pos)[1]
            # create child node
            child.game_cost = current_node.game_cost + point_gained
            child.g = child.game_cost
            child.h = heuristic(child.state)
            child.f = child.g + child.h
            heapq.heappush(fringe, child)
