from Uniform_Cost_Search.UCS import uniform_cost_search
from Environment_and_Problem.problem import Problem
from Visual_Demonstrate.demonstrate import show_board
import random
from time import perf_counter

if __name__ == "__main__":
    board_size = 8  # int(input('Board size: '))
    num_coin = 9  # int(input('Number of coins: '))
    num_obs = 8  # int(input('Number of obstacles: '))
    coin_pos_set = {(0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2), (2, 0), (2, 1), (2, 2)}
    random.seed(2)
    print('Generating environment...')

    problem = Problem(board_size=board_size, num_coin=num_coin, num_obstacles=num_obs, algorithm='UCS')
    print(
        'Environment:\nBoard_size:', problem.board_size, '\nNumber of coins:', problem.num_coin,
        '\nCoin positions set:',
        problem.coin_pos_set, '\nNumber of obstacle:', problem.num_obstacles, '\nObstacles\' set:',
        problem.obstacle_pos_set,
        '\nKnight\'s pos:', problem.knight_pos,
        '\nDestination:', problem.dest_pos, '\n')
    start = perf_counter()
    path, point = uniform_cost_search(problem)
    print('Runtime:', perf_counter() - start)
    if path != None:
        a = input('Run the demonstration of the path? [y/n] ')
        if a == 'y':
            show_board(problem.board_size, problem.knight_pos, problem.coin_pos_set, problem.obstacle_pos_set,
                       problem.dest_pos, path, problem.board.coin_value, problem.board.normal_value)
    input('Enter a key to exit.')
